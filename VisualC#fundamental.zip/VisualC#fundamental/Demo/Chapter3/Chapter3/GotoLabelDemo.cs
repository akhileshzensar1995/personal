﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class GotoLabelDemo
    {
        static void Main()
        {
            int i = 1;
            int sum = 0;
 start:            if(i <= 10)
            {
                sum = sum + i;
                
                i++;

                goto start;
            }
            Console.WriteLine(sum);
            Console.ReadLine();
        }
    }
}
