﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class GSTDemo
    {
        static void Main()
        {
            Console.WriteLine("Enter item:(Food | Service | Ornments");
            string Item = Console.ReadLine();
            if (Item == "Food")
            {
                // I2 = Console.ReadLine();
                Console.WriteLine("Tax is 5%");
                int am = Convert.ToInt32(Console.ReadLine());
                int Gst = am * 5 / 100;
                Console.WriteLine("Amount should be pay {0},{1}", am, Gst);
                
              

            }
            else if (Item == "Service")
            {
                Console.WriteLine("4%");
            }
            else if (Item == "Ornments")
            {
                Console.WriteLine("12%");
            }
            else {
                Console.WriteLine("Invalid Item");
            }


            String FoodItem;



            Console.ReadLine();
        }
    }
}
