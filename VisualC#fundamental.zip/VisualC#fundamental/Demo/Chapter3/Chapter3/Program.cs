﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter annual Income: ");
            int AI = Convert.ToInt32(Console.ReadLine());
            if (AI >= 250000)
            {
                Console.WriteLine("U R Liable to pay");
            }
            else {
                Console.WriteLine("U r not Liable to pay");
            }
            Console.ReadLine();
        }
    }
}
