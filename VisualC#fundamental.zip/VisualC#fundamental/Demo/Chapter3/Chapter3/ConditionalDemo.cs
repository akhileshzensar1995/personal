﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class ConditionalDemo
    {
        static void Main()
        {


            Console.WriteLine("Enter highest Qulification");
            string Qualification = Console.ReadLine();
            Console.WriteLine("Experince in month: ");
            int month = Convert.ToInt32(Console.ReadLine());

            if(Qualification=="PG" &&  month >= 12)
            {
                Console.WriteLine("You are eligible for Interview: ");
            }
            else
            {
                Console.WriteLine("You are not eligible for Interview");
            }
            Console.ReadLine();

        }
        
    }
}
