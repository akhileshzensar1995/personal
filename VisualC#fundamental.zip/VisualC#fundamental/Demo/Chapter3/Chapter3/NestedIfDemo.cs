﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class NestedIfDemo
    {
        static void Main()
        {
            Console.WriteLine("Enter highest Qulification");
            string Qualification = Console.ReadLine();
            Console.WriteLine("Experince in month: ");
            int month = Convert.ToInt32(Console.ReadLine());
            if (Qualification == "PG")
            {
                if (month >= 12)
                {
                    Console.WriteLine("You are Eligible for interview:");
                }
                else {
                    Console.WriteLine("Experince should be greater then 12 month :");
                }

            }
            else
            {
                Console.WriteLine("Qualification should be PG");
            }

            Console.ReadLine();
        }
    }
}
