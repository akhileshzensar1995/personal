﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class TurneryDemo
    {
        static void Main()
        {
            Console.WriteLine("Enter annual Income: ");
            int AI = Convert.ToInt32(Console.ReadLine());
            string result = AI >= 25000 ? "Yo are iligible for pay income tax" : (30000).ToString();
            Console.WriteLine(result);

            Console.ReadLine();

        }
    }
}
