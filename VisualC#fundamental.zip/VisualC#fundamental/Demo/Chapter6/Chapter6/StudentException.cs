﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class StudentException
    {
        static void Main()
        {
            Student s = new Student();
            try
            {

                
                s.InvalidRollNumber(103);
                
            }
            catch(InvalidRollNumberException e)
            {
                Console.WriteLine(e.Message);
                  

            }
            try
            {
                s.StudentName("");


            }catch(InvalidNameException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
