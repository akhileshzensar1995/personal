﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class ParamsDemo
    {
        static void Main()
        {
            MyMath m = new MyMath();
            m.Marks(50, 60, 70, 80);//here we directly pass the value .
            Console.ReadLine();

        }
    }
}
