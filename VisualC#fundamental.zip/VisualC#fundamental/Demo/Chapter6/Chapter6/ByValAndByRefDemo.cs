﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class ByValAndByRefDemo
    {
        static void Main()
        {
            MyMath m = new MyMath();
            int num = 90;
            Console.WriteLine("by value : ");
            Console.WriteLine(m.Increament(num));
            Console.WriteLine(num);
            Console.WriteLine("by referenc : ");
            Console.WriteLine(m.Increament(ref num));
           
        }
    }
}
