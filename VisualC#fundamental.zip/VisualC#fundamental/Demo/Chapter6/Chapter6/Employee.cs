﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class Employee
    {
        public void PrintNAme(string name)
        {
            if (name == "")
            {
                throw new NullReferenceException("Employee name is Null");
            }

        }
        public void ValidateEmpCode(int Empcode)
        {
            if (Empcode <= 0)
            {
                throw new InvalidEmployeeCode();
            }
        }

       
    }
}