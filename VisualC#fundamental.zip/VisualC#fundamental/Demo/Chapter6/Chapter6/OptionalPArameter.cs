﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class OptionalPArameter

    {
        static void Main()
        {
            MyMath m = new MyMath();
            Console.WriteLine(m.Size(20, msg: "this is a message"));

        }
    }
}
