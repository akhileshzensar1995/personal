﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class ThrowException
    {
        static void Main() {
            try
            {
                Employee e = new Employee();
                e.PrintNAme("");
            }
            catch(NullReferenceException e)
            {
                Console.WriteLine(e.Message);

            }
            Console.WriteLine();
        }
    }
}
