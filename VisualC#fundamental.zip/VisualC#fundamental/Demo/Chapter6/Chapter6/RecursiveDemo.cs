﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class RecursiveDemo
    {
        static void Main()
        {
            MyMath m = new MyMath();
            m.MyRecursiveFunction(1);
        }
    }
}
