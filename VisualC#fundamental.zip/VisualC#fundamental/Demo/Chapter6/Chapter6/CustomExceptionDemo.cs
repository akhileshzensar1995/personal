﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class CustomExceptionDemo
    {
        static void Main()
        {
            try
            {
                Employee emp = new Employee();
                emp.ValidateEmpCode(0);
            }catch(InvalidEmployeeCode e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadLine();

        }
    }
}
