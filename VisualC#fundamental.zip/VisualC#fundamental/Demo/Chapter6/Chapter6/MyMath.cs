﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class MyMath
    {
        public void Message()
        {
            Console.WriteLine("This is message");

        }
        public int Add(int num1, int num2)
        {
            return num1 + num2;

        }
        public double Add(double a, double b)
        {
            return a + b;
        }

        public int Increament(int x)// by value parameter
        {
            x++;
            return x;
        }
        public int Increament(ref int x)// by refernece parameter
        {
            x++;
            return x;
        }
        public int MyFunction (out int x)
        {
            x = 10;
            int y = 100;
            return y;
        }
        public int MyFunction(out int x, out int y)
        {
             x = 90;
            y = 91;
             int z = 100;
            return z;
        }
        public int Gst(out int gstAmount,int amt  )
              
        {
            gstAmount = (int)(amt * 0.05);
            return gstAmount + amt;
        }

        public String Size(int Height, int Width = 1, string msg = "Size is:")
        {
            return string.Format("{0}{1}", msg, Height + Width);
        }
        public void Marks(params int[] marks)
        {
            foreach(int temp in marks)
            {
                Console.WriteLine(temp);
            }
        }
        public void MyRecursiveFunction(int x) {

            if (x <= 10)
            {
                Console.WriteLine(x);
                x++;
                MyRecursiveFunction(x);
            }
        }

    }
}
