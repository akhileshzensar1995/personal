﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class Student
    {
        public void InvalidRollNumber(int rollnumber)
        {
            if (rollnumber >= 100)
            {
                throw new InvalidRollNumberException();
            }

        }
        public void StudentName(String name)
        {
            if (name == "")
            {
                throw new InvalidNameException();
            }

        }


    }
    class InvalidRollNumberException : Exception
    {
        public InvalidRollNumberException() : base("Invalid Rollnumber")
        {

        }




    }

    class InvalidNameException : Exception
    {

        public InvalidNameException() : base("Invalid NAme")
        {


        }

    }
}







