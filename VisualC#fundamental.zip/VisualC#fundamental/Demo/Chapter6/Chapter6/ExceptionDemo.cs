﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class ExceptionDemo
    {
        static void Main()
        {
            try
            {
                MyMath m = new MyMath();
                int num1 = Convert.ToInt32(Console.ReadLine());
                int num2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine(m.Add(num1, num2));
            }catch(FormatException e)//making object because we need to get info
            {
                Console.WriteLine("Please enter valid Input");

            }
            finally
            {
                Console.WriteLine("Final always executed");
                GC.Collect();
            }
            
            
            
            Console.ReadLine();


        }
    }
}
