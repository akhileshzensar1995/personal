﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class OutDemo
    {
        static void Main()
        {
            MyMath m = new MyMath();
            int num;
            int num1;
            
            Console.WriteLine("With sing out");
            Console.WriteLine(m.MyFunction(out num));
            Console.WriteLine(num);
            Console.WriteLine("With Multi out");
            Console.WriteLine(m.MyFunction(out num,out num1));
            Console.WriteLine(num);
            Console.WriteLine(num1);
            Console.WriteLine("Calculation OF GST");
            int gstAmount;
            int amt=1000;
            Console.WriteLine(m.Gst(out gstAmount, amt));
            Console.WriteLine(gstAmount);
           
         

        }
    }
}
