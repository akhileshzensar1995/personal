﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class SettingsDemo
    {
        public int sum;// instance level
        static void Main()
        {
            Login();
            UserDetails();

        }
        public static void Login()
        {

            Chapter6.Properties.Settings1.Default.userName = "Akhilesh";
        }

        public static void UserDetails()
        {
            string name = Chapter6.Properties.Settings1.Default.userName;
            Console.WriteLine("Welcome {0}", name);
        }
        public static void MyFun(int x)
        {
            if (true)
            {
                int y = 20;
            }

        }
    }
}
