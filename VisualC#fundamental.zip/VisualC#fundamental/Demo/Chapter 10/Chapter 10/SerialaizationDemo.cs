﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Chapter_10
{
    class SerialaizationDemo
    {
        static void Main()

        {
            //DoSerialization();

            DoDeserialization();
                Console.ReadLine();

        }
            public static void DoSerialization()
            {

            Employee emp = new Employee();
            emp.ID = 102;
            emp.Name = "Tiger";
            emp.Gender = "MAle";
            FileInfo f = new FileInfo("employee.dat"); //always make a dot file for check because it will easily generate(Relativ refrence (because we do not gave the path name ))
            Stream stream = f.Open(FileMode.Create); // for file open and creating a content
            BinaryFormatter b = new BinaryFormatter();
            b.Serialize(stream, emp);
            Console.WriteLine("Employee object is serialize");
           // Console.ReadLine();

            }
            
        public static void DoDeserialization()
        {

            Employee emp1 = new Employee();
            FileInfo f = new FileInfo("employee.dat");
            Stream stream = f.Open(FileMode.Open);
            BinaryFormatter b = new BinaryFormatter();
            emp1 = (Employee)b.Deserialize(stream);
            Console.WriteLine($"ID = {emp1.ID} NAme = {emp1.Name} Gender = {emp1.Gender}");
        }
        }
    }

