﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_10
{
    class AnonymousFunDemo
    {
        public delegate void Print(int Value);
        static void Main()
        {
            Print p = delegate (int v)
            {
                Console.WriteLine($"I am from anonymous Function: {v}");
            };
            p(100);
            Console.ReadLine();

        }
    }
}
