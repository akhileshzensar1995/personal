﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_10
{
    class TestAnonymousFunctionDemo
    {
        static void Main()
        {
            List<Employee> empList = new List<Employee>()
            {
                new Employee{ID = 101, Name = "Akhilesh",Gender = "Male" },
                new Employee{ ID = 102, Name = "Tiger", Gender = "Male" },
                new Employee { ID = 103 , Name = "Satakshi", Gender = "Female"}

            };
            Predicate<Employee> EmployeePredicate = new Predicate<Employee>(GetEmployee);

            Employee emp = empList.Find(x =>EmployeePredicate(x));
            Console.WriteLine($" ID = {emp.ID} NAme = {emp.Name } Gender ={emp.Gender}");

        }
        
        public static bool GetEmployee(Employee emp)
        {
            return emp.ID == 103;
        }


    }
}
