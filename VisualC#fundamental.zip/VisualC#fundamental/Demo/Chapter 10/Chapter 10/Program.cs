﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_10
{
    class Program
    {
        public delegate void Print(int value);
        static void Main(string[] args)
        {
            Print printDel = new Print(PrintNumber);
            //  printDel(100);
            printDel += PRintRuppees;//it wil show us two outputs like calling two function at  time
            printDel -= PRintRuppees;//For using removing 

            printDel(5000);
        }


        public static void PrintNumber(int numb)
        {
            Console.WriteLine($"Number is {numb}");
        }
        public static void PRintRuppees(int rupees)
        {
            Console.WriteLine($"Rupees is {rupees}");

        }
    }
}
