﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_10.Properties
{
    public static class IntExtension
    {
        public static bool ISGReaterThan(this int i, int value)
        {
            return i > value;
        }

    }

    public static class IntExtension2
    {

        public static bool IsPositive(this int a, int value)
        {
            if (a > 0)
            {
                Console.WriteLine(value + a);
                Console.WriteLine("Positive");
                return true;
            }
            else
            {
                Console.WriteLine("Negative");
                return false;
            }
        }

    }



        class TestExtensionMethod
        {


            static void Main()
            {

                int i = 40;
                bool result = i.ISGReaterThan(100);
                Console.WriteLine(result ? "Greater" : " Smaller");
                Console.WriteLine(i.IsPositive(8));

                Console.ReadLine();
            }
        }





    
}