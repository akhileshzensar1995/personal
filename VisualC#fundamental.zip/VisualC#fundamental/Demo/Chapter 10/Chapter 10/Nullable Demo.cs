﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_10
{
    class Nullable_Demo
    {


        static void Main()
        {
            Nullable<int> num = 40;
            Nullable<int> num2 = 50;
            Nullable<int> num3 = num + num2;
            
            if (num.HasValue)
            {
                Console.WriteLine(num.GetValueOrDefault());
            }
            else
            {
                Console.WriteLine("Object is null");
            }
            Console.WriteLine(num);
            Console.ReadLine();
        }
    }
}
