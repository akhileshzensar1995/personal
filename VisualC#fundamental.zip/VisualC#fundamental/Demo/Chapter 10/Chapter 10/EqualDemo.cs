﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_10
{
    class EqualDemo
    {

        static void Main()
        {

            int num1 = 20;
            int num2 = 30;
            Console.WriteLine(num1.Equals(num2));// It Compares Value
            Console.WriteLine(num1 == num2);// It compares Refrences
            Console.ReadLine();



        }
    }
}
