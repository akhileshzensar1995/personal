﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateTime_And_String
{
    class StringAPIDemo
    {
        static void Main()
        {

            string s = "Welcom to string class";
            string s1 = String.Copy(s);   //empty is a value basically return nothing.
            //char[] chars = s1.ToCharArray();
            //s.CopyTo(0, chars, 0, s1.Length); //to chararraay convert your string into character array
            Console.WriteLine(s1);
           

            string toSearch = "Welcome";

            if (s.StartsWith(toSearch, StringComparison.InvariantCultureIgnoreCase))
            {

                Console.WriteLine("yes"); ;
            }
            string newstr = s.Substring(8, 10);
            Console.WriteLine($"Sub string is {newstr}");
            string newMystring = String.Empty;
           
            //s = s.Trim(' ');
            foreach (string stre  in s.Split(' '))
            {
                newMystring += stre;
            }
            Console.WriteLine($"string after removing white space {newMystring}");

           


             Console.ReadLine();

            Console.ReadLine();


        }
    }
}
