﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateTime_And_String
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"System Date and Time Now is: {DateTime.Now}");
            Console.WriteLine($"System Date: {DateTime.Now.Date.ToString("dd-MMM-yyyy")}");// for creating formate of date  add 3 M for Character month
            Console.WriteLine($"Day: {DateTime.Now.Date.Day} Month {DateTime.Now.Date.Month} and Year is : {DateTime.Now.Date.Year}");//These are the nestd property

            Console.WriteLine($"After adding 8 day: {DateTime.Now.Date.AddDays(8).ToString("dd-MMM-yyyy")}");

            //Now we comparing date 

            DateTime mydate = new DateTime(2019,10, 31); // 31-12-1999 = 1 // startingpoint for calculation of compiler 
            int k = mydate.CompareTo(DateTime.Now.Date);
            if (k == 0)
            {

                Console.WriteLine($" {mydate.Date} Dat {DateTime.Now.Date}  Both date aare equal");

            }
            else if(k==1)
            {
                Console.WriteLine($" {mydate.Date} is newer than {DateTime.Now.Date}");
            }
            else
            {
                Console.WriteLine($" {mydate.Date} is older than {DateTime.Now.Date}");
            }
           double date1 =  mydate.ToOADate();
           double date2 =  DateTime.Now.Date.ToOADate();
            double days = date2 - date1;
            Console.WriteLine($"span in days : {days} ");



            Console.ReadLine();





               
        }
    }
}
