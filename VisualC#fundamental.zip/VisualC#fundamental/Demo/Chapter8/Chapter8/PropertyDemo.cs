﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Chapter8
{
    class PropertyDemo
    {
        static void Main()
        {
            Student std =  new Student() { StudentRollNo = 100, StudentName = "Akhilesh" };
            
           // std.StudentRollNo = 100;
            //std.StudentName = "Akhilesh";
            //std.SchoolNAme = "DPS";//Error
            Console.WriteLine($"Roll No { std.StudentRollNo }, Name {std.StudentName}");
            Console.ReadLine();
        }

    }
}
