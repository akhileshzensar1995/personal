﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class Student
    {
        private int RollNo;
        private string Name;
        private string SchoolName;

        public int StudentRollNo
        {
            get {
                RollNo++;
                return RollNo;

            }
            set
            {
                if(value <=0)
                {
                    Console.WriteLine("invalidRollnum");
                }
                RollNo = value;
            }
        }

        public string StudentName
        {
            get
            {
                return Name;
            }
            set
            {
                Name = value;
            }
        }
        /// <summary>
        /// Gets ANme of Summary
        /// </summary>

        public string SchoolNAme
        {
            get
            {
                return SchoolNAme;
            }
            set
            {
                SchoolNAme = value;
            }
        }

    }
}
