﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class FunctionShadowingDemo
    {
        static void Main()
        {

            MyMath2 m1 =new MyMath2();
            Console.WriteLine(m1.ADD(10.5, 10.26));
        }
    }
}
