﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class MobilePhone
    {
        int ModelNo;
        string ModelName;
        string IMEI;

        public MobilePhone()
        {

            Console.WriteLine("This is a DefaultConstructor of MobilePhone");

        }
            public MobilePhone(int ModelNo, string ModelName, string IMEI)
        {
            this.ModelNo = ModelNo;
            this.ModelName = ModelName;
            this.IMEI = IMEI;


        }
        public string ABoutMobile()
        {
            return string.Format($" Model no: {ModelNo} Model Name : {ModelName} IMEI : {IMEI}");
        }

         public void Calling()
        {
            Console.WriteLine("Is calling");
           
        }
        public void SMS()
        {
            Console.WriteLine("Messaging");
        }

        public override string ToString()
        {
            return string.Format($" Model no: {ModelNo} Model Name : {ModelName} IMEI : {IMEI}");
        }


        ~MobilePhone()
               {
            Console.WriteLine("Garbage is collected for Mobile");

              }


    }
}
