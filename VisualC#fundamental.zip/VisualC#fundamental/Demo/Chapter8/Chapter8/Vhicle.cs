﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
   public abstract class Vhicle
    {
        
        public Vhicle()
        {
            Console.WriteLine("Default Constructor of Vhicle");
        }
        public string Start()
        {
            return "Start the vhicle";
        }
        public string Stop ()
        {
            return "Stop the vhicle";
        }

        public abstract string Start(string type); 


    


  partial  class Fourwheeler : Vhicle
    {
            //There sre diffrent segment of cars 
            public override string Start(string type)
            {
                return $"This will start using {type}";
            }
        }
    class AbstractDemo
    {

        static void Main()
        {
            Fourwheeler TataIndica = new Fourwheeler();
            Console.WriteLine(TataIndica.Start());
            Console.WriteLine(TataIndica.Stop());
                Console.WriteLine(TataIndica.Start("Key"));
            Console.ReadLine();


        }

    }

}
