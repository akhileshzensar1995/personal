﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    interface IWIFI
    {
     string StartWifi();
      string StopWifi();
    }

    class NokiLumia : MobilePhone, IWIFI
    {
      public  string StartWifi()
        {
            return "Starting Wifi";
        }
         public string StopWifi()
        {
            return "Stoping Wifi";
        }
    }
    class NokiaLumia2 : NokiLumia
    {
        public string PushMessage()
        {
            return "Calling from nokialumia2";
        }
    }
    class InterfaceDemo
    {

        static void Main()
        {

            IWIFI i = new NokiLumia();//explicit call  interface
            NokiLumia nl = new NokiLumia();
               nl.Calling();
            Console.WriteLine(i.StartWifi());
            Console.WriteLine(i.StopWifi());
            Console.ReadLine();
        }

    }

}
