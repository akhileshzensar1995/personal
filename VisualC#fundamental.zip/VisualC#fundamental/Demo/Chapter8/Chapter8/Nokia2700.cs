﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class Nokia2700 : MobilePhone
    {
        public Nokia2700()
        {
            Console.WriteLine("Default construtor of nokia2700");

        }
        public string MP4()
        {
            return " MP$ calling from Nokia2700";
        }
        public string camera()
        {
            return "Camera of 2700 is calling";

        }
    }
}