﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class FunctionOverridingDemo
    {
        static void Main()
        {
            MyMath2 m2 = new MyMath2();
           Console.WriteLine(m2.Increament(10));
            Console.ReadLine();
        }
    }
}
