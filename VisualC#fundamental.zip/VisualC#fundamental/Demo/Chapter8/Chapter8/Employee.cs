﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    static class Employee
    {
        static Employee()
        {
            Console.WriteLine("Default Constructor of static class");
        } 
        public static string Details(int empcode, string name)
        {
            return string.Format($"Employee code is {empcode}  and Employee name is {name}");
        }


    }
    class Staticdemo
    {
        static void Main()
        {
            Console.WriteLine(Employee.Details(54321, "Akhilesh"));
            Console.ReadLine();


        }



    }
}
