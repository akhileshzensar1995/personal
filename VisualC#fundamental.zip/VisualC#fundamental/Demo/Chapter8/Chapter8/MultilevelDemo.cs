﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class MultilevelDemo
    {
       static void main()
        {
            NOKIA1100 nOKIA = new NOKIA1100();
            nOKIA.Calling();
            nOKIA.MP3();
            nOKIA.Radio();



        }
    }
}
