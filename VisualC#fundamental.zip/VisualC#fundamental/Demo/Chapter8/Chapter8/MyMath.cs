﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class MyMath
    {
        public int ADD(int num1, int num2)
        {
            return num1 + num2;

        }

        public string Add(string str1, string str2)
        {
            return str1 + str2;
        }

        public virtual int Increament(int x)
        {
            x++;
            return x;
        }

        public new double ADD(double num1, double num2)
        {
            return num1 + num2;
        }

    }

    class MyMath2 : MyMath
    {
        public override int Increament(int x)
        {
            x = x + 10;
            return x; 
        }

        }
    class MyMAth3 : MyMath2
    {
        public sealed override int Increament(int x)   //(Sealed)it is like a final method  we can not use.
        {
            x = x + 50;
            return x;
        }

    }

}
