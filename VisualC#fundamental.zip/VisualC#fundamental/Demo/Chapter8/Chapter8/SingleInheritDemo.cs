﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class SingleInheritDemo
    {
        static void Main()
        {
            Creater();
            GC.Collect();
            Console.ReadLine();
        }

        public static void Creater()
        {

            NOKIA1400 nk = new NOKIA1400();
            nk.Calling();
            nk.SMS();

           
        }

    }
}
