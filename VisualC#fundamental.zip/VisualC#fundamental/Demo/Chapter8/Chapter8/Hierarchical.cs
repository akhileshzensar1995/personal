﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class Hierarchical
    {
        static void Main()
        {

            Nokia2700 nokia2700 = new Nokia2700();
            nokia2700.Calling();
            nokia2700.camera();
            //nokia2700.ABoutMobile();
            Console.ReadLine();
        }
       

    }
}
