﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class NOKIA1100:NOKIA1400
    {
        public NOKIA1100()
        {
            Console.WriteLine();
        }

        public string MP3()
        {
            return "Calling MP3 from NOkia1100";
        }
    }
}
