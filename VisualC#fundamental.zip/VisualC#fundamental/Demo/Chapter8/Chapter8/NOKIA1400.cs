﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class NOKIA1400: MobilePhone
    {
      public NOKIA1400()
        {
            Console.WriteLine("Default constructor Of NOKIA1400");
        }

       public string Radio()
        {
            return "Radio in NOkIA 1400";
        }



        ~NOKIA1400()
        {

            Console.WriteLine("Garbage is Calling from NOKIA1400 instance");

        }
    }
}
