﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class FunOverLoadingDemo
    {
        static void Main()
        {

            MyMath m = new MyMath();
            Console.WriteLine(m.ADD(5, 6));
            Console.WriteLine(m.Add("Hello", "World"));
            Console.WriteLine();

        }
    }
}
