﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMPUTER
{
    public class Software
    {
        string Apptype;
        string AppName;
        int Appver;

        public Software(string Apptype, string AppName, int Appver)
        {
            this.Apptype = Apptype;
            this.AppName = AppName;
            this.Appver = Appver;

        }
        public string Display()
        {

            return $"Application Type : {Apptype}\n Application Name : {AppName}\n Application Version : {Appver} ";

        }
        public string TroublShoot()
        {
            return "Troubleshooting";
        }




    }
}
