﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMPUTER
{
   public class Hardware
    {

        string DeviceType;
        string DeviceName;
        int DeviceID;

        public Hardware(string DeviceType, string DeviceName, int DeviceID)
        {
            this.DeviceType = DeviceType;
            this.DeviceName = DeviceName;
            this.DeviceID = DeviceID;

        }

        public string Display()
        {
            return $"Device Type : {DeviceType}\n Device NAme : {DeviceName} \n Device Id :  {DeviceID}" ;

        }

        public string TroublShoot()
        {
            return "Troubleshooting";
        }



    }
}
