﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class TakeInput
    {
         static void Main()
        {
            Console.WriteLine("Enter the number1: ");
            int num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the number2: ");
            int num1 = Convert.ToInt32(Console.ReadLine());
            int sum = num + num1;
            Console.WriteLine("Sum of {0} and {1}, {2}", num, num1, sum);
            Console.ReadLine();
        }
    }
}
