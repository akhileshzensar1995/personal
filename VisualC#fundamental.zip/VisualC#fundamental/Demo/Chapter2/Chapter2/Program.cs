﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    /// <summary>
    /// This is simple class
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {




        }
        /// <summary>
        /// This function is printing text message
        /// </summary>

        public void Message()
        {
            Console.WriteLine("Hii Akhilesh");
            
        }
        /// <summary>
        /// para func
        /// </summary>
        /// <param name="s">str</param>
        /// <returns>str</returns>
        public string Message(string s) {
            return s;
        }
       
    }


}
