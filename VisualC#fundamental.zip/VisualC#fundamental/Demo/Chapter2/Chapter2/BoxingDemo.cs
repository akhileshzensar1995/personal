﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class BoxingDemo
    {
        static void Main()
        {
            int i = 10;
            object o = i;
            Console.WriteLine(o);
            Console.ReadLine();
        }
    }
}
