﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class ConstDemo
            {
        static void Main()
        {
            const double pi = 3.14;

            int a = 10;
            double aoc = a * a * pi;
            Console.WriteLine(aoc);
            Console.ReadLine();

        }
    }
}
