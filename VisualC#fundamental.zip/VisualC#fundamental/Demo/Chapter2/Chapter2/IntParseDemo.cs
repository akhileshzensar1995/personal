﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class IntParseDemo
    {
        static void Main()
        {

            string str = "50";
            int num = int.Parse(str);
            Console.WriteLine(num);
            Console.ReadLine();
        }
    }
}
