﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class DynamicDemo
    {
        static void Main()
        {
            dynamic num = 10;
            Console.WriteLine("Type of num is {0}",num.GetType());
            dynamic s = "akhilesh";
            Console.WriteLine("Type of num is {0}", s.GetType());
            Console.ReadLine();
        }
    }
}
