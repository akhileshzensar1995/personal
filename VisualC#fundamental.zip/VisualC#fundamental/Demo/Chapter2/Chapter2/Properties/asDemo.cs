﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2.Properties
{
    class asDemo
    {
        static void Main()
        {
            object[] o = { 10, 20, "Akhilesh" };
            string s = o[2] as string;
            if (s!=null) {
                Console.WriteLine(s);
            }
            Console.ReadLine();

        }
    }
}
