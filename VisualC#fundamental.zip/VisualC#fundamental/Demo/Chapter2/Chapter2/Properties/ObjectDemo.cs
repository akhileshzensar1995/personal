﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2.Properties
{
    class ObjectDemo
    {
        static void Main()
        {

            object o = 10, o1 = "Akhilesh", o2 = 32.6, o3 = 'B', o4 = true;
                ;
            Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}",o,o1,o2,o3,o4);
            Console.ReadLine();
        }
    }
}
