﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class VarDemo
    {
        static void Main()
        {
            int[] num = { 10, 20, 30, 40 };
            var v = num;
            foreach (var temp in v)
            {
                Console.WriteLine(temp);
            }
            Console.ReadLine();

        }
    }
}
