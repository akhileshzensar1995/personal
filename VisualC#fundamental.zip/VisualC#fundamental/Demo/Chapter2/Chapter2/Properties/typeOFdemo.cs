﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2.Properties
{
    class typeOFdemo 
    {
        static void Main(string []args)
        {
            Type t = typeof(int);
            Type t1 = typeof(long);
            Type t2 = typeof(short);
            Console.WriteLine("int = {0} Long = {1} Short = {2}", t,t1,t2);
            


            Console.ReadLine();

        }

    }
}
