﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class TryParseDemo
    {
        static void Main()
        {
            String s = "50";
            int outvar;
            bool IsComp = int.TryParse(s,out outvar);
            if (IsComp)
            {
                Console.WriteLine(outvar);
            }
            else
            {
                Console.WriteLine("Conversion is not compatible");
                    
            }
            Console.ReadLine();
        }
        
    }
}
