﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class Class1
    {
        static void Main(string[]args)
        {
            Program p = new Program();
            p.Message();
           // p.Message("Thisis the new Value");
            Console.Write(p.Message("Thisis the new Value"));
            Console.ReadLine();
        }
    }
    class Class2:Class1
    {


    }
}
