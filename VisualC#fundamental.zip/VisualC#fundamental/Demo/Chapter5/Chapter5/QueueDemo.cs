﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Chapter5
{
    class QueueDemo
    {
        static void Main()
        {
            Console.WriteLine("For Queue");
            Queue book = new Queue();
            book.Enqueue(1234);
            book.Enqueue(125);
            book.Enqueue(124);
            foreach(var v in book)
            {
                Console.WriteLine(v);
            }
           Console.WriteLine("After removing {0}" ,book.Dequeue());
            Console.WriteLine("now Queue is ");
            foreach (var v in book)
            {
                Console.WriteLine(v);
            }
            Console.WriteLine("next element to be removing {0}",book.Peek());
            Console.WriteLine("now Queue is ");
            foreach (var v in book)
            {
                Console.WriteLine(v);
            }


            Console.WriteLine("For Stack");
            Stack stk = new Stack();
            stk.Push(123);
            stk.Push(124);
            stk.Push(125);
            stk.Push(126);
            foreach (var v in stk)
            {
                Console.WriteLine(v);
            }

           Console.WriteLine("After removing the element{0}",stk.Pop());
            Console.WriteLine("Now Stack is ");
            foreach (var v in stk)
            {
                Console.WriteLine(v);
            }



          Console.ReadLine();
        }
    }
}
