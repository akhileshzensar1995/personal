﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Chapter5
{
    class HashTableDemo
    {
        static void Main()
        {
            Hashtable Gst = new Hashtable();
            Gst.Add("maharastra", 27);
            Gst.Add("gujrat", 24);
            Gst.Add("delhi", 12);

            Console.WriteLine("Enter the city name ");
            string s = Console.ReadLine();
            if (Gst[(s).ToLowerInvariant()] == null)
            {
                Console.WriteLine("invalid state");
                
            }
            else
            {
                Console.WriteLine("Std Code of city is {0}", Gst[(s).ToLowerInvariant()]);
            }
            Console.WriteLine("All keys from Gst: ");
            foreach(var v in Gst.Keys)
            {
                Console.WriteLine("Keys = {0} and value  = {1}",v,Gst[v]);
            }

            Gst.Remove("delhi");
            Console.WriteLine("After remove delhi");
            foreach (var v in Gst.Keys)
            {
                Console.WriteLine("Keys = {0} and value  = {1}", v, Gst[v]);
            }

        }

    }
}
