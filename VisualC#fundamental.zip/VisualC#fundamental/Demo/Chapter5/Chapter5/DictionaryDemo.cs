﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class DictionaryDemo
    {

        static void Main()
        {

            Dictionary<int, string> myPairs = new Dictionary<int, string>();
            /*
           
               {
                { 1,"Ten"}{10,"ten"} // with initializer 
            };*/

            myPairs.Add(1, "One");
            myPairs.Add(20, "Twenty");
            myPairs.Add(30, "Thirty");
            myPairs.Add(40, "Fourty");
            Console.WriteLine($"Count is {myPairs.Count}");
            Console.WriteLine($"Value is {myPairs[10]}");
            if (myPairs.Remove(10))
            {
                Console.WriteLine($"Count is {myPairs.Count}");
            }
            foreach(var temp in myPairs.Keys)
            {
                Console.WriteLine($"Key is {temp} and value is {myPairs[temp]}");
            }
                    
                    

        }
    }
}
