﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Concurrent;


namespace Chapter5
{
    class GenericsDemo
    {
        static void Main()
        {
            Queue<int> q = new Queue<int>();///We are doing Unboxing
            q.Enqueue(12);
            //q.Enqueue("Akhilesh");//Show error becaus it is not casted

            Stack<int> stk = new Stack<int>();
            stk.Push(10);
            stk.Push(20);
            //stk.Push("asd");//Showing error becaue it is not casted
         }
    }
}
