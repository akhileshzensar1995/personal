﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class ArrrayClassDemo
    {
        static void Main()

        {
            int[] num = { 12, 10, 28, 23, 19 };
            int[] dum = new int[5];
            int [,] num1 = new int[2, 3]; 

            num.CopyTo(dum, 0);
            Console.WriteLine("After the copy element ");
            foreach(int n in dum)
            {
                Console.WriteLine(n);
            }
            dum.SetValue(55, 3);
            Console.WriteLine("After replacing 14 with 55");
            foreach(int n in dum)
            {
                Console.WriteLine(n);
            }
            Console.WriteLine("Value of Index 2 is {0}", dum.GetValue(2));
            Console.WriteLine("Upperbound of dums is 0", dum.GetUpperBound(0));
            Console.WriteLine("Upperbound for num1 {0} is {0} and num1 {1} is {1}", num1.GetUpperBound(0),num1.GetUpperBound(1));
            Console.WriteLine("Number of Dim are{0}", num1.Rank);
            Array.Sort(dum);//Short in assending order
            Console.WriteLine("After short the dum");
            foreach(int n in dum)
            {
                Console.WriteLine(n);
            }




            Console.ReadLine();
               
        }
    }
}
