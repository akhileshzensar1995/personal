﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Chapter5
{
    class ArraylistDemo
    {
        static void Main()
        {
            ArrayList std = new ArrayList();
            std.Add(100);
            std.Add("Scott");
            std.Add("asdfhjkj@123");
            std.Add('m');
            std.Add(true);
            std.Capacity = std.Count;//stop westaging of memory (otherwise here it ccan take 8 capacity instead of 5) 
            Console.WriteLine("Total count is {0} Capasity {1}", std.Count,std.Capacity);
            foreach(var t in std)
            {
                Console.WriteLine(t);
            }

            std.Remove(100);
            std.Capacity = std.Count;
            Console.WriteLine("After removing the value");
            foreach (var t in std)
            {
                Console.WriteLine(t);
            }
            Console.WriteLine("Total count is {0} Capasity {1}", std.Count, std.Capacity);
            Console.WriteLine("100 is there ? {0}", std.Contains(100));
            std.Clear();
            Console.WriteLine("After removing all elements");
            std.Capacity = std.Count;//stop westaging of memory (otherwise here it ccan take 8 capacity instead of 5) 
            Console.WriteLine("Total count is {0} Capasity {1}", std.Count, std.Capacity);

            Console.ReadLine();


        }
    }
}
