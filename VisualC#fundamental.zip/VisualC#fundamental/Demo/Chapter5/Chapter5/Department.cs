﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class Department
    {
        public int departmentCode { get; set; }
    }

    class Employee
    {
        public int EmployeeCode { get; set; }
        public string EmployeeName { get; set; }

        public int departmentCode { get; set; }

         }

    class Details
    {

        static void Main()
        {
            Dictionary<Department, Employee> dt = new Dictionary<Department, Employee>();
            Department dp = new Department { departmentCode = 101 };
            Department dp1 = new Department { departmentCode = 102 };
            Employee e1 = new Employee { EmployeeCode = 58123, EmployeeName = "Akhilesh", departmentCode = 101 };
            Employee e2 = new Employee { EmployeeCode = 58126, EmployeeName = "Abhishek", departmentCode = 102 };
            dt.Add(dp,e1);
            dt.Add(dp1, e2);
            foreach (var v in dt.Keys)
            {

            Console.WriteLine($" Employee name is: {dt[v].EmployeeName} Employee Code is: {dt[v].EmployeeCode} Employee DepartmentCode is {dt[v].departmentCode} KEys is {dt[v].departmentCode}" );
            }
            Console.ReadLine();

              



        }

    }


}
