﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class Student
    {
        public int Rollnumber { get; set; }
        public String NAme { get; set; }

      
    }
}
