﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
namespace Chapter5
{
    class SortedListDemo
    {
        static void Main()
        {
            SortedList<int, string> mySortedList = new SortedList<int, string> {
                { 1, "ont"},{10,"Ten"},{ 30,"Thirty"}
            };
            Console.WriteLine($"Count is {mySortedList.Count}");
            foreach(int Key in mySortedList.Keys)
            {
                Console.WriteLine($"Key is {Key} and Value is {mySortedList[Key]}");
            }
            if (mySortedList.Remove(10))
            {
                Console.WriteLine($" After Removing Count is {mySortedList.Count}");
            }
            foreach (int Key in mySortedList.Keys)
            {
                Console.WriteLine($"Key is {Key} and Value is {mySortedList[Key]}");
            }
            Console.ReadLine();

        }
    }
}
