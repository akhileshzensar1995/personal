﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] nums = { 10, 20, 30, 40, 50 };
            int[] nums1 = new int []{ 10, 20, 30, 40, 50 };
            int[] num2 = new int[5];

            Console.WriteLine("Enter how many element  want: ");
            int value = Convert.ToInt32(Console.ReadLine());

            for (int i =0; i <value; i++)
            {

                num2 [i] = Convert.ToInt32(Console.ReadLine());
            }
            
         
        }
    }
}
