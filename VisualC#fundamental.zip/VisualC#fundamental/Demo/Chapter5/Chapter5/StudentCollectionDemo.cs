﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
    
{
    /// <summary>
    /// User defing Collection Dmo
    /// 
    /// </summary>
    class StudentCollectionDemo
    {

        static void Main()
        { 
      

            List<Student> students = new List<Student>() {

                new Student { Rollnumber = 10, NAme = "Akhilesh" },//We are creating constructor for returning object so we directly use new KeyWorld
            new Student { Rollnumber = 20, NAme = "Abhishek" }

            };


            foreach (Student std in students)
            {
                Console.WriteLine($"RollNo is:  {std.Rollnumber} and Name is :{std.NAme} ");

            }
            Console.ReadLine();
        }
    }
}
