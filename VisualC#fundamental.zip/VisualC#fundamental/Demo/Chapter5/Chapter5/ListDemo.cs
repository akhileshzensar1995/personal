﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
namespace Chapter5
{
    class ListDemo
    {
        static void Main()
        {


            //List<int> myList = new List<int>(); //Impliment all the methods of list;
            IList<int> myList = new List<int>();
            myList.Add(10);
            myList.Add(20);
            myList.Add(30);
            myList.Add(40);
            myList.Add(50);
            Console.WriteLine($"Count of element is {myList.Count}");

            foreach(int l in myList)
            {
                Console.WriteLine(l);
            }
            Console.WriteLine("We want to remove some number ");
          
            Console.WriteLine("After removing the Element");
            if (myList.Remove(20))
            {

                Console.WriteLine($" count is : {myList.Count}");
            }

            foreach (int l in myList) {
                Console.WriteLine(l);
            }

            
           


        }
    }
}
