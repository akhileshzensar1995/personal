﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter7
{
   enum Colors
    {
        red=120, green=200, orange = red
    }
    enum Colors1
    {
        red = Colors.green,green =200, orange = Colors.orange

    }
    enum GST
    {
        MAharastra = 27,Gujrat = 24, Delhi = 12, UP = 30, MP = 32, AP = 42
    }
}
