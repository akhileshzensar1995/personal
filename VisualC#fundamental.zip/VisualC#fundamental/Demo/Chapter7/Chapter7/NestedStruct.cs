﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter7
{
    class NestedStruct
    {
    }
    struct MyDate
    {
        public struct MyMonth
        {
            public enum Month
            {
                jan = 1, feb = 2, march = 3, april = 4, may = 5, jun = 6, july = 7, august = 8, sep = 9, oct = 10, nov = 11, dec = 12
            };
        }
        public struct MyYear
        {
            public enum Year
            {
                year1 = 2019, year2 = 2020, year3 = 2021
            };
        }
    }



    class Enumeration
    {

        static void Main()
        {
            Console.WriteLine(MyDate.MyMonth.Month.jan.GetHashCode());
            foreach(string name in Enum.GetNames(typeof(MyDate.MyMonth.Month))){
                Console.WriteLine($"NAme of Months is:{name}");
            }

            foreach(int value in Enum.GetValues(typeof(MyDate.MyYear.Year)))
            {
                Console.WriteLine($"Year of Months is :{value}");
            }
            Console.ReadLine();
        }
       

    }


}


