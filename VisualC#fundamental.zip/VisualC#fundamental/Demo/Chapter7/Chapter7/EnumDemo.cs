﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter7
{
    class EnumDemo
    {
        static void Main()
        {

            Console.WriteLine(Colors.red);
           
            Console.WriteLine(Colors.red.GetHashCode());//We can use Convert.Toint32(colors.Red);

            Console.WriteLine(Colors.orange);
            Console.WriteLine(GST.Delhi.GetHashCode());
            Console.WriteLine("++++++++++++++Enumerate OF Enum+++++++++");

            foreach(string name in Enum.GetNames(typeof(GST)))
            {
                Console.WriteLine(name);
            }
            foreach (int value in Enum.GetValues(typeof(GST)))
            {
                Console.WriteLine(value);

             }

            Console.ReadLine();
        }
    }
}
