﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter7
{
    class Program
    {
        static void Main(string[] args)
        {
            Book mybook = new Book(123,"c#4.0","Danish Marsh");
           Console.WriteLine( mybook.Display());


        }
    }
}
