﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using COMPUTER;

namespace Computer_with_Console
{
    class Program
    {
        static void Main(string[] args)
        {

            Software s = new Software("Application OIn software", "Ms World", 2015);
            Console.WriteLine($"{s.Display()}");
            Hardware h1 = new Hardware("Application OIn software", "Ms World", 2015);
            Console.WriteLine($"{s.TroublShoot()}");
        }
    }
}
