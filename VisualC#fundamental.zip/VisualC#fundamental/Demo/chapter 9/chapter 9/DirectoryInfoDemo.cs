﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace chapter_9
{
    class DirectoryInfoDemo
    {
        static void Main() {

            DirectoryInfo dir = new DirectoryInfo("My Folder");

            if (!dir.Exists)
            {
                dir.Create();
                Console.WriteLine("Directory created ");
               

            }

            if (dir.Exists)
            {
                Console.WriteLine($"Full Name : {dir.FullName}");
                Console.WriteLine($"NAme : {dir.Name}");
                Console.WriteLine($"Creation Time : {dir.CreationTime}");
                Console.WriteLine($"Last Access time : {dir.LastAccessTime}");
                
            }


          /*  if (dir.Exists)
            {

                dir.Delete();
                    Console.WriteLine("Directory deleted");
            }*/


            if (dir.Exists)
            {
                foreach(DirectoryInfo d in dir.GetDirectories())
                {
                    Console.WriteLine($"{ d.Name} is deleted");
                    d.Delete();
                }

            }

            if (dir.Exists)
            {
                foreach(FileInfo f in dir.GetFiles())
                {
                    Console.WriteLine($"{ f.Name} is deleted");
                    f.Delete();
                }

            }

            Console.ReadLine();

        }
    }
}