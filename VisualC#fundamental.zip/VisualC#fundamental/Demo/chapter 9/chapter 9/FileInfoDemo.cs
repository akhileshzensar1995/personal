﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace chapter_9
{
    class FileInfoDemo
    {
        static void Main()
        {
            FileInfo f = new FileInfo("try.txt"); //this is a static class and asking file(anytype) name as a string.
            if (f.Exists)
            {
                Console.WriteLine($"fill full path: {f.FullName}");// name along with base adress.
                Console.WriteLine($"Fill Name: {f.Name}");
                Console.WriteLine($"File extension : {f.Extension}");
                Console.WriteLine($"File Size : {f.Length} bytes");
                Console.WriteLine($"File attribute : {f.Attributes}"); //file may be archive or anythingelse
                Console.WriteLine($"Creation Time: {f.CreationTime}");
                Console.WriteLine($"Flie last access time : {f.LastAccessTime}");

               // Console.ReadLine();

            }
            //Here are some methods of File handling: 
            if (f.Exists)
            {
                f.CopyTo(@"D:\TestfileInfo.txt",true);
                Console.WriteLine("File is copied Successfully");
               // Console.ReadLine();
            }

          /*  if (f.Exists)
            {
                f.MoveTo(@"C:\try.txt");
                Console.WriteLine("File is moved");
              Console.ReadLine();
            }*/



            FileInfo f1 = new FileInfo(@"D:\try.txt");
            if (f1.Exists)
            {
                f1.Delete();
                Console.WriteLine("File Deleted Successfully");
            }
            Console.ReadLine();

        }
    }
}
