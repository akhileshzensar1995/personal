﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace chapter_9
{
    class DriverInfoDemo
    {

        static void Main()
        {

            DriveInfo div = new DriveInfo("D: ");
            /*   if (div.IsReady)
               {

                   Console.WriteLine($"Drive Name: {div.Name}");
                   Console.WriteLine($"Drive Volume Label: {div.VolumeLabel}");
                   Console.WriteLine($"Total space : {div.TotalSize} bytes");
                   Console.WriteLine($"Total Free space : {div.TotalFreeSpace} bytes");
                   Console.WriteLine($"Drive Type : {div.DriveType} ");
                   Console.WriteLine($"Drive Type : {div.DriveFormat} ");

               }
               */
            foreach (DriveInfo drv in DriveInfo.GetDrives()) ;
            { 
            if (div.IsReady)
            {
                Console.WriteLine($"Drive Name: {div.Name}");
                Console.WriteLine($"Drive Volume Label: {div.VolumeLabel}");
                Console.WriteLine($"Total space : {div.TotalSize} bytes");
                Console.WriteLine($"Total Free space : {div.TotalFreeSpace} bytes");
                Console.WriteLine($"Drive Type : {div.DriveType} ");
                Console.WriteLine($"Drive Type : {div.DriveFormat} ");

            }
            Console.WriteLine();
        }
        Console.ReadLine();


        }
    }
}
