﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace chapter_9
{
    class ReadFileDemo
    {

        static void Main()
        {

            StreamReader sr = new StreamReader("try.txt");
            string str = sr.ReadToEnd();//this will read your entire File
            Console.WriteLine(str);
            Console.ReadLine();


        }

    }
}
