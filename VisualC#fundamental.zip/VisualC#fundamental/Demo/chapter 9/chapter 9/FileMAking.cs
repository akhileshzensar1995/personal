﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace chapter_9
{
    class FileMAking
    {
        static void Main(string[] args)
        {
            StreamWriter sw = new StreamWriter("try.txt"); //("try.txt") it is a (Relative path)directpath for making txt file in Debug folder(Current filder)
            sw.WriteLine(" new Text Appended");
            sw.Close();
            Console.WriteLine("File has Written successfully");
            Console.ReadLine();
        }
    }
}
