﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter4
{
    class ForEachDemo
    {
        static void Main()
        {
            string[] name = { "Akhilesh", "Ram", "Abhishek", "Sushant" };

            foreach(string s in name)
            {
                Console.WriteLine(s);
            }
            object[] o = { 10, 20, "a", true };
            foreach (var v in o)
            {
                Console.WriteLine(v);
            }

            Console.ReadLine();
        }
    }
}
