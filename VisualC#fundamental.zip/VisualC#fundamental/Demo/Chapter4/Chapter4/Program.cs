﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("==========For Loop==========");
            int sum = 0;
            for(int i =1; i <=15; i++)
            {
                sum = sum + i;
                Console.WriteLine(sum);
            }
            Console.WriteLine("=============Whileloop================");
            int j = 1;
            sum = 0;
            while (j <= 15)
            {

                sum = sum + j;
                Console.WriteLine(sum);
                j++;

            }
            Console.WriteLine("===========Do while loop===========");
            j = 2;
            sum = 0;
            do
            {
                sum = sum + j;
                Console.WriteLine(sum);
                j++;
            } while (j <= 10);
                
            Console.ReadLine();



        }
    }
}
