﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter4
{
    class odd_value
    {
        static void Main() {
            int[] nums = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };
            Console.WriteLine("Odd one is:");
            for(int i = 0;i<12;i++)
            {
                if (nums[i]% 2!=0)
                {
                    Console.WriteLine(nums[i]);
                }
            }
            Console.ReadLine();
                }
    }
}
