﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int i =50;i>= 1;i--)
            {
                Console.WriteLine(i);
            }
        }
    }
}
