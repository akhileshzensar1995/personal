﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7
{
    enum CityEnum
    {
        Delhi = 20145, Mumbai = 3456, Dehradun = 248001, Pune = 411007
    }

    class CityStd
    {

        static void Main()
        {
            Console.WriteLine("City Names Are: ");
            foreach (string name in Enum.GetNames(typeof(CityEnum)))
            {
                Console.WriteLine(name);

            }
            Console.WriteLine("CityCodes Are");
            foreach (int value in Enum.GetValues(typeof(CityEnum)))
            {
                Console.WriteLine(value);

            }
            

              


        }
    }
}