﻿using System;

namespace ConsoleApp2
{
    /// <summary>
    /// Converting character to Ascii value
    /// 
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {

            char ch = 'A';
            int a = (int)ch;
            Console.WriteLine($" Ascii value of A :{a}");// Printing Ascii value
            Console.ReadLine();

        }
    }
}
