﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    /// <summary>
    /// We find the area 
    /// 
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            const double pi = 3.14; //We provide the hardcoded value
            double r = 10;
            double area =  (pi * r * r);

            Console.WriteLine($"Are of circle : { area}");
            Console.ReadLine();

        }
    }
}
