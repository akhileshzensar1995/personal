﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Program2
    {
        static void Main()
        {
            Console.WriteLine("Enter the PErcentage below: ");
            double perc = Convert.ToDouble(Console.ReadLine());

            if(perc >= 60 && perc < 100)
            {
                Console.WriteLine("Grade is A");
            }else if(perc >= 40 && perc< 60)
            {
                Console.WriteLine("Grade is B");
            }else if( perc >= 10 && perc < 40)
            {
                Console.WriteLine("Grade is c");
            }
            else
            {
                Console.WriteLine("Fail");
            }

        }
    }
}
