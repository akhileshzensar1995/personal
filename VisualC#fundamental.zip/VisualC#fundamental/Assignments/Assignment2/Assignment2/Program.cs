﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Age Below: ");
            int age = Convert.ToInt32(Console.ReadLine());
            if(age > 18)
            {
                Console.WriteLine("Person is Major");
            }else
            {
                Console.WriteLine("Person is Minor");
            }

            Console.ReadLine();

        }
    }
}
