﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6
{
    class Program5
    {
        static int Gst(int amount, int gstrate = 1)
        {
            int gst = amount * gstrate / 100;

            return gst;
        }
        static void Main()
        {

            Console.WriteLine("Enter Amount");
            int amount = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"Total gst is : {Gst(amount)}");


        }
    }
}
