﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6
{
    class Program4
    {
        static double SimpleInterest(out double totalamount, int amount, int month)
        {
             totalamount = ((amount*6*month) / 100)+amount;
            int si = (amount * 6 * month) / 100);

            return si ;

        }
        static void Main()
        {
            Console.WriteLine("Enter amount");
            double amount = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter months");
            int month = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"Simple Interest ={SimpleInterest(out totalamount, amount, month)}");

            Console.ReadLine();

        }
    }
}
