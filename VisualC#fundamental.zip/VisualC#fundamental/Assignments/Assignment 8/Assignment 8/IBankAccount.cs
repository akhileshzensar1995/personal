﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_8
{
    interface IBankAccount
    {
        void Deposit(double amount);
         void Withdrawl(double amount);
    }

    class SavingAccount : IBankAccount
    {
        double balance = 0;
        public void Deposit(double amount)
        {
            balance = balance + amount;
            Console.WriteLine($"Amount is Deposite : {amount} and Balance is {balance}");

        }

        public void Withdrawl(double amount)
        {
            if (amount <= balance)
            {

                balance = balance - amount;
                Console.WriteLine($" Amount withdraw : {amount}, now Balance is {balance}");
            }
            else
            {
                Console.WriteLine($"Balance is : {balance}");

            }
        }


    }
    class CurrentAccount: IBankAccount
    {
        double Bln = 1000;

        public void Deposit(double amt)
        {
            Bln = Bln + amt;
            Console.WriteLine($"Amount is Deposite : {amt} and Balance is {Bln}");

        }

        public void Withdrawl(double amt)
        {
            if (amt <= Bln)
            {

                Bln = Bln - amt;
                Console.WriteLine($" Amount withdraw : {amt}, now Balance is {Bln}");
            }
            else
            {
                Console.WriteLine($"Balance is : {Bln}");

            }
        }



    }

    class BankRequirement
    {
        static void Main()
        {
           
            Console.WriteLine("Please choose number(1|2) : 1= Saving Account | 2= Current Account ");
            int Choice = Convert.ToInt32(Console.ReadLine());
            switch (Choice)
            {
                case  1:  Console.WriteLine("Saving Account");

                    SavingAccount s = new SavingAccount();
                    Console.WriteLine("Enter Amount deposit");
                    double a = Convert.ToDouble(Console.ReadLine());
                    s.Deposit(a);
                    Console.WriteLine("Enter Amount to be Withdrawn");
                    double b = Convert.ToDouble(Console.ReadLine());
                    s.Withdrawl(b);
                    break;

                case 2: Console.WriteLine("Current Account");

                    CurrentAccount c = new CurrentAccount();
                    Console.WriteLine("Enter Amount deposit");
                    double a1 = Convert.ToDouble(Console.ReadLine());
                    c.Deposit(a1);
                    Console.WriteLine("Enter Amount to be Withdrawn");
                    double b1 = Convert.ToDouble(Console.ReadLine());
                    c.Withdrawl(b1);
                   break;
           
            }
            Console.ReadLine();



        }

    }


}
