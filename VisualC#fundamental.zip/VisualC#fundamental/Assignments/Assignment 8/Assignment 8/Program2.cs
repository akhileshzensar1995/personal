﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_8
{

    sealed class Pen
    {
        public string StartWriting()
        {
            return "Pen is start writing ";
        }


        public string StopWriting()
        {
            return "Pen is stop Writing";
        }


    }

   class Program2
    {
        static void Main()
        {

            Pen p = new Pen();
            Console.WriteLine(p.StartWriting());
            Console.WriteLine(p.StopWriting());
            Console.ReadLine();

        }

    }
}
