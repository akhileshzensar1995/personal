﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_8
{
    class User
    {
        private long ID;
        private string name;
        private string emailID;
        private string dateOfBirth;

        public User()
        {
            Console.WriteLine("This is default constructor of USer");
            
        }


        public User(long ID, string name, string emailID, string dateOfBirth)
        {
            this.ID = ID;
            this.name = name;
            this.emailID = emailID;
            this.dateOfBirth = dateOfBirth;

        }

        public override string ToString()
        {
            return string.Format($" ID : {ID}\n Name : {name}\n Email ID: {emailID}\n Date Of Birth : {dateOfBirth} ");
        }

    }
    class Forum
    {

        static void Main()
        {
            Console.WriteLine("Please choose one (1|2): 1= Registration | 2: Display  ");
            int c = Convert.ToInt32(Console.ReadLine());
            switch (c)
            {

                case 1 :    Console.WriteLine("Please register below: ");

                    User u = new User();
                    Console.WriteLine("Enter the ID");
                    long i = Convert.ToInt64(Console.ReadLine());
                    Console.WriteLine("Enter the name ");
                    string n = Console.ReadLine();
                    Console.WriteLine("Enter  email ID");
                    string e = Console.ReadLine();
                    Console.WriteLine("Date OF Birth");
                    string dt = Console.ReadLine();

                    break;

                case 2:   Console.WriteLine("Below are Details: ");
                    User u1 = new User();

                    Console.WriteLine(u1.ToString());

                         
                    break;
            }

            Console.ReadLine();






        }

    }






}
