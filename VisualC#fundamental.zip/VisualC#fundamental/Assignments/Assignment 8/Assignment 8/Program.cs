﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_8
{
    /// <summary>
    /// 
    /// it is a abstract class
    /// 
    /// </summary>


  public abstract class Computer
    {

         public string Bootup()
        {
            return "System is booted";
        }

         public string Shutdown()
        {
            return "System is shutdown";
        }
        
        }
    class SuperComputer: Computer
    {
     }
    class MAinframComputer : Computer { }
    class MicroComputr : Computer { }

    class Program1
    {
        static void Main(string []args)
        {
            SuperComputer sc = new SuperComputer();
            Console.WriteLine(sc.Bootup());
            Console.WriteLine(sc.Shutdown());
            
        }


    }





}
