﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GST;

namespace GstImplimentation_by_own_Liberary
{
    class Program
    {
        static void Main(string[] args)
        {
            Gst g = new Gst(1000);
            Console.WriteLine(g.TotalGst());
            Console.ReadLine();
           
        }
    }
}
