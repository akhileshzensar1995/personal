INSERT INTO SALES.CUSTOMERS(first_name,last_name,email)
 VALUES ('Virat','Masd','virat1234@mohal.com'),
('sunil','Mukiia','aunil@mohal.com'),
    ('AKash','Singh','akash@singh123.com'),
	 ('Ankush','Shukla','ah@singh123.com'),
	  ('Ankita','Singh','ankita@singh123.com')
	
	
	SELECT * FROM SALES.CUSTOMERS  

	-----UPDATE SET-------

	UPDATE SALES.CUSTOMERS SET first_name = 'Aman', last_name = 'Rawat',
	email = 'aman@123' where customer_id = 12;


	------DELETE-----------

	DELETE FROM SALES.CUSTOMERS where customer_id = 10;
	DELETE  TOP(2) FROM dbo.person
	TRUNCATE TABLE SALES.CUSTOMERS

	SElect * from person