--CREATE DATABASE BIKESMODEL


--CREATE SCHEMA SALES 

--CREATE SCHEMA PRODUCTION

CREATE TABLE SALES.STORES(

store_id        INT IDENTITY(1,1) PRIMARY KEY,
 store_name      VARCHAR(20) NOT NULL,
 phone           VARCHAR(10),
 email            VARCHAR(100),
 city             VARCHAR (100),
 state            VARCHAR (50),
 zip_code           VARCHAR (5)          
 )

 CREATE TABLE SALES.QOTATIONS(
 qotation_no    INT IDENTITY(1,1) PRIMARY KEY,
 valid_from     DATE NOT NULL,
 valid_to       DATE NOT NULL
  )

  -- FOR ADDING TABLES
  ALTER TABLE SALES.QOTATIONS
  ADD DESCRIPTION VARCHAR(50) NOT NULL

  ALTER TABLE SALES.QOTATIONS
  ALTER COLUMN  DESCRIPTION VARCHAR(30) NOT NULL


  ALTER TABLE SALES.QOTATIONS -- DROPCOLUMS OF EXISTING TABLE
  DROP COLUMN DESCRIPTION

 drop table person

  CREATE TABLE person(
  person_id    int identity primary key,
  firs_name     varchar(50) NOT NULL,
 last_name     varchar(50) NOT NULL, 
 dob                date
  
  )


  INSERT INTO person(firs_name,last_name,dob)
   values ('Sachin','Tendulkar','1978-02-03'),
   ('Saurav','Ganguly','1975-02-03'),
   ('Rahul','Dravid','1973-02-03')
   
ALTER TABLE person
ADD full_name as (firs_name+' '+last_name);
  


EXEC sp_rename 'persons','person'    --(only for rename table)


-- Making temprory table(for declaring global tbale add one more #)


drop table #vipperson
Create Table #vipperson(
person_id int,
first_name varchar(20) not null,
last_name  varchar(20) not null 
)

INSERT INTO #vipperson
select person_id,firs_name,last_name
from person

select * from  #vipperson;

-----Primary key and foreign key constrant---
Create Table SALES.STAFFS(

staff_id  INT PRIMARY KEY,
first_name  VARCHAR(50)NOT NULL,
last_name  VARCHAR(50)NOT NULL,
email  VARCHAR(50)NOT NULL,
store_Id  INT NOT NULL,
CONSTRAINT fk_staffs_stores FOREIGN KEY (store_ID)
References SALES.STORES(store_ID)
)

----check constrant-----
create table SALES.ORDERED_ITEMS(
order_id INT NOT NULL,
item_id INT NOT NULL,
order_quantity INT CHECK(order_quantity> 0) not null,
unit_price INT CHECK(unit_price> 0) Not Null

)
INSERT INTO SALES.ORDERED_ITEMS VALUES(1,1,5,100)

SELECT * FROM SALES.ORDERED_ITEMS



ALTER TABLE SALES. ORDERED_ITEMS
ADD item_amount as (unit_price*order_quantity)

--UNIQUE CONSTRANT-------

CREATE TABLE SALES.CUSTOMERS(
customer_id INT PRIMARY KEY IDENTITY,
first_name  VARCHAR(50)NOT NULL,
last_name  VARCHAR(50)NOT NULL,
email  VARCHAR(50) UNIQUE
)
INSERT INTO SALES.CUSTOMERS(first_name,last_name,email)
 VALUES ('Virat','Mahol','virat@mohal.com'),
--- ('Virat','Mukiia','virat@mohal.com'),--- it will show u error coz of duplicate value
    ('AKash','Singh','akash@singh.com')


	SELECT * FROM SALES.CUSTOMERS



















