﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SchoolApplication_EntityFramework;
using SchoolApplication_EntityFramework.BLL;

namespace SchoolApplication_EntityFramework
{
    class Program
    {
        static void Main(string[] args)
        {

            StanderdBll stdbll = new StanderdBll();
            Console.WriteLine
                ("Choose one 1: Save Stander 2: dlete standerd");
            int i = Convert.ToInt32(Console.ReadLine());
            switch (i)
            {

                #region SaveStanderd
                case 1:
                    Standerd std = new Standerd()
                    {                                                                       // WE PUT DATA INTO TABLEB
                        StanderdId = 3,
                        StanderdName = "Third",
                        Description = "Junior"

                    };
                    if (stdbll.SaveStanderd(std))
                    {
                        Console.WriteLine("Standerd Add Successfuly");
                    }
                    else
                    {
                        Console.WriteLine("Error occured");
                    }

                    break;
                #endregion


                #region Delet Standerd
                case 2:

                    if (stdbll.DelteStanderd())
                    {
                        Console.WriteLine("Standerd Deleted Successfuly");
                    }
                    else
                    {
                        Console.WriteLine("Error occured");
                    }

                    break;
                    #endregion







            }

            Console.ReadLine();
        }
    }
}
