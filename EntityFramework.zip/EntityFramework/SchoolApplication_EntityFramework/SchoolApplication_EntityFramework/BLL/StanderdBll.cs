﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolApplication_EntityFramework.BLL
{
    class StanderdBll
    {
        public bool SaveStanderd(Standerd std)
        {
            // Standerd s = new Standerd();


            try
            {

                using (DBschoolEntities dbcontext = new DBschoolEntities()) /// using keyword for Manual Despose
                {
                    dbcontext.Standerds.Add(std);
                    dbcontext.SaveChanges();
                    
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }




        }

        public bool DelteStanderd()
        {
            try
            {
                using (DBschoolEntities dbcontexxt =  new DBschoolEntities())
                {
                    // var s = dbcontexxt.Standerds.First<Standerd>();
                    //var s = dbcontexxt.Standerds.Find(3); // value findng i  primary key tble;
                    var s = dbcontexxt.Standerds.First<Standerd>(x => x.StanderdId = 3);// via lemda function
                    dbcontexxt.Standerds.Remove(s);
                    dbcontexxt.SaveChanges();
                }


                    return true;

            }catch(Exception e)
            {
                return false;
            }




        }



        public bool UpdateStanderd(Standerd std)
        {
            try
            {
                using (DBschoolEntities dbContext = new DBschoolEntities())
                {
                    Standerd s1 = new Standerd();
                    s1.StanderdId = std.StanderdId;


                    dbContext.SaveChanges();
                                      
                }



                    return true;
            }catch(Exception ex)
            {

                return false;
            }




        }
    }
}
