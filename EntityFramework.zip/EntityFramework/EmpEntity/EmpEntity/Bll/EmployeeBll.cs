﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpEntity.Bll
{
    class EmployeeBll
    {
        public bool SaveEmployee(EmpMaster emp)
        {
            try
            {

                using (EMPZensarEntities empcontext = new EMPZensarEntities())
                {
                    empcontext.EmpMasters.Add(emp);
                    empcontext.SaveChanges();
                }


                return true;
            }
            catch (Exception ex)
            {
                return false;
            }


        }

        public bool DelteEmployee()
        {
            try
            {
                using (EMPZensarEntities dbcontexxt = new EMPZensarEntities())
                {
                   // var s = dbcontexxt.EmpMasters.First<EmpMaster>();
                    var s = dbcontexxt.EmpMasters.Find(3); // value findng i  primary key tble;
                    //var s = dbcontexxt.Standerds.First<Standerd>(x => x.StanderdId = 3);// via lemda function
                    dbcontexxt.EmpMasters.Remove(s);
                    dbcontexxt.SaveChanges();
                }


                return true;

            }
            catch (Exception e)
            {
                return false;
            }






        }
    }
}
