﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpEntity;
using EmpEntity.Bll;

namespace EmpEntity
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeBll ebll = new EmployeeBll();

            Console.WriteLine
               ("Choose one 1: Save 2: delete");
            int i = Convert.ToInt32(Console.ReadLine());
            switch (i)
            {
                case 1:
                #region Save Employee 
            EmpMaster emp = new EmpMaster()
                  {
                      EmpCode = 6,
                      EmpName = "Ram",
                      EmpDob = Convert.ToDateTime("1994-12-15"),
                      EmpGender = "MAle",
                      EmpDepartment = "Sales",
                      EmpDesignation = "Manager"
                  };
            if (ebll.SaveEmployee(emp))
            {
                Console.WriteLine("Employee Imported");
            }
            else
            {
                Console.WriteLine("Error Occured in your Program");
            }

            break;

                #endregion

                case 2:

                    #region : Delete
                    if (ebll.DelteEmployee())
                    {
                        Console.WriteLine("Employee Deleted Successfuly");
                    }
                    else
                    {
                        Console.WriteLine("Error occured");
                    }

                    break;

                   #endregion



                        }

          
            Console.ReadLine();
        }


    }
    
}
